# Aplicación Híbrida Big-Data (Opción A — todo en Ubuntu, sin GPU)

GPU-preproc (OpenMP/CPU) + Spark (RDD y DataFrame) + Modelo de Actores (Pykka) + serverless HTTP.
Diseñado para correr completo en un **Ubuntu Server**, sin GPU. La normalización usa
la versión CPU con OpenMP (fallback automático). El código CUDA (`gpu-service/normalize.cu`)
se incluye como entregable; solo se compila donde haya GPU.

## Requisitos del sistema (una sola vez)
```bash
sudo apt update
sudo apt install -y python3 python3-venv default-jdk build-essential curl unzip tmux
```
`default-jdk` es para Spark, `build-essential` para el kernel OpenMP, `curl` para las pruebas.

## Puesta en marcha (3 pasos)
```bash
# 1) Configurar (crea el venv e instala TODO dentro de él)
./setup.sh

# 2) Arrancar los 3 servicios  (para la demo de reintentos: SIMULATE_FAILS=2 ./start.sh)
./start.sh

# 3) En OTRA terminal, disparar el pipeline
./demo.sh
```
Cuando termines:
```bash
./stop.sh
```

## Notas
- **No hace falta activar el venv**: los scripts usan `venv/bin/python` por ruta absoluta.
- `start.sh` espera a que Spark caliente y, si algo falla, imprime el log del error.
- Grabar por SSH: usa `tmux` (dividir paneles: `Ctrl+b` luego `%`).

## Endpoints
- `POST /process`  (orquestador, :5000) — inicia el pipeline; devuelve resultado + log.
- `GET  /result/<id>` — recupera un resultado persistido en `results/`.
- `POST /normalize` (:5001) y `POST /spark` (:5002) — servicios individuales.

## Estructura
```
gpu-service/    normalize_cpu.c (OpenMP) · normalize.cu (CUDA, entregable) · app.py
spark-service/  spark_job.py (RDD+DataFrame) · app.py
orchestrator/   actors.py (Pykka) · app.py
data/           generate_dataset.py
setup.sh start.sh stop.sh demo.sh
```
