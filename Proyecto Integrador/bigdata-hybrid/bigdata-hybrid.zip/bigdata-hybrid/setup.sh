#!/usr/bin/env bash
# Configura el proyecto UNA sola vez: venv + dependencias + kernel CPU.
set -e
cd "$(dirname "$0")"

echo ">> Creando entorno virtual (venv)..."
python3 -m venv venv

echo ">> Instalando dependencias DENTRO del venv..."
./venv/bin/pip install --upgrade pip -q
./venv/bin/pip install -r requirements.txt

echo ">> Compilando kernel CPU (OpenMP)..."
bash gpu-service/build.sh

echo ""
echo "Setup completo. Verificacion de dependencias:"
./venv/bin/python -c "import flask, pykka, requests, pyspark; print('   deps OK')"
echo ""
echo "Siguiente paso:  ./start.sh    (y en otra terminal:  ./demo.sh)"
