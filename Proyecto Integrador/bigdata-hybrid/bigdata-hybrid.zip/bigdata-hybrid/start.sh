#!/usr/bin/env bash
# Arranca los 3 microservicios. Usa el python del venv por ruta absoluta,
# asi que NO depende de que el venv este 'activado'.
#   Uso normal:            ./start.sh
#   Con fallos simulados:  SIMULATE_FAILS=2 ./start.sh   (para la demo de reintentos)
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"
PY="$ROOT/venv/bin/python"

if [ ! -x "$PY" ]; then
  echo "ERROR: no existe el venv. Ejecuta primero:  ./setup.sh"
  exit 1
fi

mkdir -p "$ROOT/results"
echo ">> Compilando kernel CPU..."
bash "$ROOT/gpu-service/build.sh"

echo ">> Arrancando GPU (5001), Spark (5002) y Orchestrator (5000)..."
SIMULATE_FAILS="${SIMULATE_FAILS:-0}" "$PY" "$ROOT/gpu-service/app.py"  > /tmp/bdh_gpu.log   2>&1 & echo $! > /tmp/bdh_gpu.pid
( cd "$ROOT/spark-service"  && "$PY" app.py > /tmp/bdh_spark.log 2>&1 ) & echo $! > /tmp/bdh_spark.pid
( cd "$ROOT/orchestrator"   && "$PY" app.py > /tmp/bdh_orch.log  2>&1 ) & echo $! > /tmp/bdh_orch.pid

echo ">> Esperando a que los servicios respondan (Spark tarda ~15-20s)..."
READY=0
for i in $(seq 1 45); do
  if curl -s localhost:5001/health >/dev/null 2>&1 \
  && curl -s localhost:5002/health >/dev/null 2>&1 \
  && curl -s localhost:5000/health >/dev/null 2>&1; then
    READY=1; break
  fi
  sleep 1
done

if [ "$READY" = "1" ]; then
  echo ""
  echo "======================================================"
  echo " TODO LISTO. En otra terminal ejecuta:   ./demo.sh"
  echo " Para detener los servicios:             ./stop.sh"
  echo "======================================================"
else
  echo ""
  echo "!! Los servicios no respondieron a tiempo. Ultimas lineas de log:"
  echo "----- GPU -----";   tail -n 6 /tmp/bdh_gpu.log
  echo "----- SPARK ---";   tail -n 6 /tmp/bdh_spark.log
  echo "----- ORCH ----";   tail -n 6 /tmp/bdh_orch.log
  echo "(revisa el error de arriba; luego  ./stop.sh  y reintenta)"
fi
