#!/usr/bin/env bash
# Detiene los 3 microservicios.
for f in /tmp/bdh_gpu.pid /tmp/bdh_spark.pid /tmp/bdh_orch.pid; do
  if [ -f "$f" ]; then kill "$(cat "$f")" 2>/dev/null; rm -f "$f"; fi
done
# por si acaso, liberar los puertos
for p in 5000 5001 5002; do fuser -k ${p}/tcp 2>/dev/null; done
echo "Servicios detenidos."
