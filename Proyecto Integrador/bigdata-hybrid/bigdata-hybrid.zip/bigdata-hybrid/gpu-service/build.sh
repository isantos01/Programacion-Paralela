#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
gcc -O2 -fopenmp normalize_cpu.c -o normalize_cpu
echo "[build] normalize_cpu (OpenMP/CPU) OK"
# normalize.cu (CUDA) es un entregable; solo se compila donde haya GPU (p.ej. Colab).
