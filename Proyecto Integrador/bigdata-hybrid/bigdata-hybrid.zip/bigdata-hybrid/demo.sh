#!/usr/bin/env bash
# Envia una peticion al pipeline completo y muestra la respuesta formateada.
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
PY="$ROOT/venv/bin/python"
ARR=$("$PY" -c "import json,random;print(json.dumps([random.randint(0,10000) for _ in range(5000)]))")
echo "=== POST /process (pipeline completo) ==="
curl -s -X POST localhost:5000/process -H "Content-Type: application/json" \
  -d "{\"array\": $ARR}" | "$PY" -m json.tool
